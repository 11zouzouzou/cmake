// 配置版本头文件 cmake中注入  1和的值0将被替换。
#define Tutorial_VERSION_MAJOR 1
#define Tutorial_VERSION_MINOR 0
//与cmake中的option配合使用
#define USE_MYMATH
