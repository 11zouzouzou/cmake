//声明sqrt函数
double mysqrt(double x);